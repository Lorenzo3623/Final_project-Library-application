﻿using NLog;

namespace ButtonGrind.Utlity
{
	public class MyLogger : Ilogger
	{
		private static MyLogger instance;
		public static Logger logger;

		public static MyLogger GetInstance()
		{
			if(instance == null)
				instance = new MyLogger();
			return instance;
		}
		private Logger GetLogger()
		{
			if (MyLogger.logger == null)
				MyLogger.logger = LogManager.GetLogger("LoginApperule");
			return MyLogger.logger; 

		}
		public void Debug(string message) { 
		GetLogger().Debug(message);
		}
		public void Info(string message)
		{
		GetLogger().Info(message);
		}
		public void Warning(string message)
		{
			throw new NotImplementedException();
		}
		public void Error(string message)
		{
			throw new NotImplementedException();
		}
	}
}
