﻿using System.ComponentModel.DataAnnotations;

namespace ButtonGrind.Models
{
    public class UserModel
    {
        public int UserID { get; set; }  

        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Display(Name = "Sex")]
        public string Sex { get; set; }

        [Required]
        [Range(0, 150, ErrorMessage = "Please enter a valid age")]
        public int Age { get; set; }

        [Display(Name = "State")]
        public string State { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required]
        [Display(Name = "Username")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Username must be between 3 and 50 characters")]
        public string Username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        [StringLength(100, MinimumLength = 6, ErrorMessage = "Password must be at least 6 characters long")]
        public string Password { get; set; }
    }
}
