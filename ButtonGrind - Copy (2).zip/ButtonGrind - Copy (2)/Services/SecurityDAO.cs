﻿ using ButtonGrind.Models;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
namespace ButtonGrind.Services
{
    // This class handles database operations for security and book management
    public class SecurityDAO
    {
        // Connection string to the database
        string connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Test;Integrated Security=True;";

        // Method to find a user by username and password
        public bool FindUserByNameAndPassword(UserModel user)
        {
            bool success = false;  // Assume the user is not found
            string sqlStatement = "SELECT * FROM dbo.Users WHERE username = @username AND password = @password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.Add("@username", System.Data.SqlDbType.VarChar, 50).Value = user.Username;
                command.Parameters.Add("@password", System.Data.SqlDbType.VarChar, 50).Value = user.Password;

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.HasRows)  // If rows are found, the user exists
                        success = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);  // Log any exceptions
                }
            }
            return success;
        }
        // Method to insert a new user into the database with password hashing
        public bool InsertUser(UserModel user)
        {
            if (UserExists(user.Username, user.Email))
            {
                // User already exists
                return false;
            }

            bool success = false;
            string sqlStatement = "INSERT INTO dbo.Users (FirstName, LastName, Sex, Age, State, Email, Username, Password) VALUES (@FirstName, @LastName, @Sex, @Age, @State, @Email, @Username, @PasswordHash)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@FirstName", user.FirstName);
                command.Parameters.AddWithValue("@LastName", user.LastName);
                command.Parameters.AddWithValue("@Sex", user.Sex ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Age", user.Age);
                command.Parameters.AddWithValue("@State", user.State ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@Email", user.Email);
                command.Parameters.AddWithValue("@Username", user.Username);

                // Hash the password (uncomment and implement the hash method as needed)
                // string passwordHash = ComputeSha256Hash(user.Password);
                string passwordHash = user.Password; // Replace with hashed password
                command.Parameters.AddWithValue("@PasswordHash", passwordHash);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    success = rowsAffected > 0;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return success;
        }


        // Helper method to compute SHA256 hash
        //private string ComputeSha256Hash(string rawData)
        //{
        //    using (SHA256 sha256Hash = SHA256.Create())
        //    {
        //        // ComputeHash returns byte array
        //        byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

        //        // Convert byte array to a string
        //        StringBuilder builder = new StringBuilder();
        //        foreach (var t in bytes)
        //        {
        //            builder.Append(t.ToString("x2"));
        //        }
        //        return builder.ToString();
        //    }
        //}

        // Method to save a user's game state


        // Method to delete a user record by ID
        public bool Delete(int id)
        {
            bool isDeleted = false;
            string sqlStatement = "DELETE FROM dbo.users5 WHERE Id = @id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@id", id);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    isDeleted = rowsAffected > 0;  // Check if the record was deleted
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return isDeleted;
        }

        // Method to retrieve all books from the database
        public List<BookModel> GetAllBooks()
        {
            List<BookModel> foundBooks = new List<BookModel>();
            string sqlStatement = "SELECT * FROM Books";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        foundBooks.Add(new BookModel(
                            (int)reader["BookId"],
                            reader["Title"].ToString(),
                            reader["Author"].ToString(),   // Added Author
                            reader["ISBN"].ToString(),
                            reader["Genre"].ToString()
                        ));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return foundBooks;
        }

        // Method to retrieve a single book by its ID
        public BookModel GetBookById(int id)
        {
            BookModel foundBook = null;
            string sqlStatement = "SELECT * FROM Books WHERE BookId = @BookId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@BookId", id);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        foundBook = new BookModel(
                            (int)reader["BookId"],
                            reader["Title"].ToString(),
                            reader["Author"].ToString(),   // Added Author
                            reader["ISBN"].ToString(),
                            reader["Genre"].ToString()
                        );
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return foundBook;
        }


        // Method to update a book's details in the database
        public bool UpdateBook(BookModel book)
        {
            bool success = false;
            string sqlStatement = "UPDATE Books SET Title = @Title, Author = @Author, ISBN = @ISBN, Genre = @Genre WHERE BookId = @BookId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@Title", book.Title);
                command.Parameters.AddWithValue("@Author", book.Author);   // Added Author
                command.Parameters.AddWithValue("@ISBN", book.ISBN);
                command.Parameters.AddWithValue("@Genre", book.Genre);
                command.Parameters.AddWithValue("@BookId", book.Id);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    success = rowsAffected > 0;  // Check if the book was updated
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return success;
        }


        // Method to delete a book from the database
        public bool DeleteBook(int id)
        {
            bool isDeleted = false;
            string sqlStatement = "DELETE FROM Books WHERE BookId = @BookId";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@BookId", id);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    isDeleted = rowsAffected > 0;  // Check if the book was deleted
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return isDeleted;
        }

        // Method to add a new book to the database
        public bool InsertBook(BookModel book)
        {
            bool success = false;
            string sqlStatement = "INSERT INTO Books (Title, Author, ISBN, Genre) VALUES (@Title, @Author, @ISBN, @Genre)";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@Title", book.Title);
                command.Parameters.AddWithValue("@Author", book.Author);   // Added Author
                command.Parameters.AddWithValue("@ISBN", book.ISBN);
                command.Parameters.AddWithValue("@Genre", book.Genre);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    success = rowsAffected > 0;  // Check if the book was added
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return success;
        }

        public List<UserModel> GetAllUsers()
        {
            List<UserModel> users = new List<UserModel>();
            string sqlStatement = "SELECT * FROM dbo.Users";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        UserModel user = new UserModel
                        {
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Sex = reader["Sex"].ToString(),
                            Age = Convert.ToInt32(reader["Age"]),
                            State = reader["State"].ToString(),
                            Email = reader["Email"].ToString(),
                            Username = reader["Username"].ToString(),
                            // Exclude password for security reasons
                        };
                        users.Add(user);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return users;
        }
        public bool UserExists(string username, string email)
        {
            bool exists = false;
            string sqlStatement = "SELECT COUNT(*) FROM dbo.Users WHERE Username = @Username OR Email = @Email";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@Email", email);

                try
                {
                    connection.Open();
                    int count = (int)command.ExecuteScalar();
                    exists = count > 0;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return exists;
        }
        public bool CheckOutBook(int bookId)
        {
            bool success = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlTransaction transaction = null;

                try
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();

                    // Get book details
                    string getBookSql = "SELECT * FROM Books WHERE BookId = @BookId";
                    SqlCommand getBookCommand = new SqlCommand(getBookSql, connection, transaction);
                    getBookCommand.Parameters.AddWithValue("@BookId", bookId);
                    SqlDataReader reader = getBookCommand.ExecuteReader();

                    if (reader.Read())
                    {
                        string title = reader["Title"].ToString();
                        string author = reader["Author"].ToString();
                        string isbn = reader["ISBN"].ToString();
                        string genre = reader["Genre"].ToString();
                        reader.Close();

                        // Insert into Books2
                        string insertSql = "INSERT INTO Books2 (Title, Author, ISBN, Genre) VALUES (@Title, @Author, @ISBN, @Genre)";
                        SqlCommand insertCommand = new SqlCommand(insertSql, connection, transaction);
                        insertCommand.Parameters.AddWithValue("@Title", title);
                        insertCommand.Parameters.AddWithValue("@Author", author);
                        insertCommand.Parameters.AddWithValue("@ISBN", isbn);
                        insertCommand.Parameters.AddWithValue("@Genre", genre);
                        insertCommand.ExecuteNonQuery();

                        // Delete from Books
                        string deleteSql = "DELETE FROM Books WHERE BookId = @BookId";
                        SqlCommand deleteCommand = new SqlCommand(deleteSql, connection, transaction);
                        deleteCommand.Parameters.AddWithValue("@BookId", bookId);
                        deleteCommand.ExecuteNonQuery();

                        transaction.Commit();
                        success = true;
                    }
                    else
                    {
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    transaction?.Rollback();
                }
            }

            return success;
        }
        public List<BookModel> GetBooks2()
        {
            List<BookModel> books = new List<BookModel>();
            string sqlStatement = "SELECT * FROM Books2";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(sqlStatement, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        books.Add(new BookModel(
                            (int)reader["BookId"],
                            reader["Title"].ToString(),
                            reader["Author"].ToString(),
                            reader["ISBN"].ToString(),
                            reader["Genre"].ToString()
                        ));
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return books;
        }
        public bool CheckInBook(int bookId)
        {
            bool success = false;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlTransaction transaction = null;

                try
                {
                    connection.Open();
                    transaction = connection.BeginTransaction();

                    // Get book details
                    string getBookSql = "SELECT * FROM Books2 WHERE BookId = @BookId";
                    SqlCommand getBookCommand = new SqlCommand(getBookSql, connection, transaction);
                    getBookCommand.Parameters.AddWithValue("@BookId", bookId);
                    SqlDataReader reader = getBookCommand.ExecuteReader();

                    if (reader.Read())
                    {
                        string title = reader["Title"].ToString();
                        string author = reader["Author"].ToString();
                        string isbn = reader["ISBN"].ToString();
                        string genre = reader["Genre"].ToString();
                        reader.Close();

                        // Insert into Books2
                        string insertSql = "INSERT INTO Books (Title, Author, ISBN, Genre) VALUES (@Title, @Author, @ISBN, @Genre)";
                        SqlCommand insertCommand = new SqlCommand(insertSql, connection, transaction);
                        insertCommand.Parameters.AddWithValue("@Title", title);
                        insertCommand.Parameters.AddWithValue("@Author", author);
                        insertCommand.Parameters.AddWithValue("@ISBN", isbn);
                        insertCommand.Parameters.AddWithValue("@Genre", genre);
                        insertCommand.ExecuteNonQuery();

                        // Delete from Books
                        string deleteSql = "DELETE FROM Books2 WHERE BookId = @BookId";
                        SqlCommand deleteCommand = new SqlCommand(deleteSql, connection, transaction);
                        deleteCommand.Parameters.AddWithValue("@BookId", bookId);
                        deleteCommand.ExecuteNonQuery();

                        transaction.Commit();
                        success = true;
                    }
                    else
                    {
                        reader.Close();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    transaction?.Rollback();
                }
            }
            return success;

        }
    }
}
