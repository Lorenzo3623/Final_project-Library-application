﻿using ButtonGrind.Models;
using ButtonGrind.Services;
using Microsoft.AspNetCore.Mvc;

namespace ButtonGrind.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Account/ProcessRegistration
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ProcessRegistration(UserModel user)
        {
            if (ModelState.IsValid)
            {
                SecurityDAO dao = new SecurityDAO();
                bool success = dao.InsertUser(user);
                if (success)
                {
                    // Registration successful, redirect to a success page or login
                    return View("Success");
                }
                else
                {
                    // Display an error message
                    ViewBag.ErrorMessage = "Username or Email already exists.";
                    return View("Register", user);
                }
            }
            // Redisplay the form with validation errors
            return View("Register", user);
        }


        // Login action and view
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Success()
        {
            // pass data to the view using ViewBag or a model
            return View();
        }
        public IActionResult ListUsers()
        {
            SecurityDAO dao = new SecurityDAO();
            List<UserModel> users = dao.GetAllUsers();
            return View(users);
        }
        // POST: Account/AdminLogin
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AdminLogin(string username, string password)
        {
            // Check if the username is "admin" and password is "password"
            if (username == "admin" && password == "password")
            {
                // Redirect to Books/Index2 view
                return RedirectToAction("Index2", "Books");
            }
            else
            {
                // Login failed, display an error message
                ViewBag.ErrorMessage = "Invalid username or password.";
                return View("Login");
            }
        }
    }
}
